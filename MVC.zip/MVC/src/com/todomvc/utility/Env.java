package com.todomvc.utility;

public class Env {
	
	public static String browserUsed = "GC"; //GC FF IE SA
	public static String mcvUrl = "http://todomvc.com/examples/angularjs/#/";
	public static String reportpath = "E:/Reports/";

}
