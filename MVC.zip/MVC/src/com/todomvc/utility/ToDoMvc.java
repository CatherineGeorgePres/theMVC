package com.todomvc.utility;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class ToDoMvc extends Util{
	
	public static ObjectRepository or = new ObjectRepository();
	
	public static boolean addAToDoList(String toDoItem){
		boolean flag = false;
		WebElement actionObject = editSetValue(or.whatNeedsToBeDone_EB, toDoItem);
		 pressEnterKey(actionObject);
		 
		 //Verify if the event is successfully added
		List<String> toDoListString = getAllToDoList();
		if (toDoListString.contains(toDoItem)) {
			flag = true;
		}
		return flag;
	}
	
	
	public static List<String> getAllToDoList(){
		boolean flag = false;
		List<WebElement> toDoList = driver.findElements(By.xpath(or.toDoList));
		List<String> toDoListString = getStringList(toDoList);
		return toDoListString;
	}
	public static Integer verifyIfToDoItemPresent(String toDoItem){
		Integer itemIndex = -1;
		List<String> toDoListString = getAllToDoList();
		for (int i = 0; i < toDoListString.size(); i++) {
			if (toDoListString.get(i).equals(toDoItem)) {
				itemIndex =  i+1;
				break;
			}
		}
		return itemIndex;
	}
	
	public static void editToDoItem(String toDoItem, String editTo){
		Integer itemIndex = verifyIfToDoItemPresent(toDoItem);
		Actions action = new Actions(driver);
		WebElement we1 = driver.findElement(By.xpath("(//label[@class='ng-binding'])[" +itemIndex+ "]"));
		action.doubleClick(we1).sendKeys(Keys.SHIFT, Keys.HOME, Keys.DELETE, Keys.SHIFT, editTo, Keys.ENTER).perform();
	}
	
	public static int completeToDoItem(String toDoItem){
		Integer itemIndex = -1;
		try {
			itemIndex = verifyIfToDoItemPresent(toDoItem);
			btnClick("(//input[@ng-model='todo.completed'])[" +itemIndex +"]");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return itemIndex;
	}

	public static int clearToDoList(String toDoItem){
		Integer itemIndex = -1;
		try {
			itemIndex = verifyIfToDoItemPresent(toDoItem);
			WebElement actionObject = driver.findElement(By.xpath("(//input[@ng-model='todo.completed'])[" +itemIndex +"]"));
			mouseHover(actionObject);
			btnClick("(//button[@class='destroy'])[" + itemIndex + "]");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return itemIndex;
	}
	
	public static void mouseHover(WebElement actionObject){
		Actions action = new Actions(driver);
		action.moveToElement(actionObject).build().perform();
	}

}
