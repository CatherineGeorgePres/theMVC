package com.todomvc.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



public class Util {
	static WebDriver driver;
	static ExtentReports report;
	static ExtentTest test;
	
	public Util() {
		report = new ExtentReports(Env.reportpath + "report.html");
		test = report.startTest("Test Script 1");
	}
	
	public void closeBrowser(){
		driver.quit();
		report.endTest(test);
		report.flush();
	}
	
	public static void	writeReport(String status, String stepName){
		if (status.equals("PASS")) {
			test.log(LogStatus.PASS, stepName);
		}else{
			test.log(LogStatus.FAIL, stepName);
		}
		
	}
	
	public void	openBrowser(String url){
		String browser = Env.browserUsed;
		if (browser.equals("GC")) {
			System.setProperty("webdriver.chrome.driver", "E:/b24frameowrkPath/lib/chromedriver.exe");
			driver = new ChromeDriver();
		}else if (browser.equals("FF")) {
			driver = new FirefoxDriver();
		}else if (browser.equals("IE")) {
			//TODO:System.setProperty("webdriver.chrome.driver", "D:/softwares/chromedriver.exe");
			driver = new InternetExplorerDriver();
		}
//		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		navigate(url);
	}
	
	public void	 navigate(String url){
		driver.get(url);
	}
	
	public static WebElement editSetValue(String xpath, String valueToBeSet){
		WebElement actionObject = driver.findElement(By.xpath(xpath));
		actionObject.clear();
		actionObject.sendKeys(valueToBeSet);
		return actionObject;
	}
	
	public static void pressEnterKey(WebElement actionObject){
		actionObject.sendKeys(Keys.ENTER);
	}
	
	public static List<String> getStringList(List<WebElement> webElements){
		List<String> stringList = new ArrayList<String>();
		for (WebElement webElement : webElements) {
			stringList.add(webElement.getText());
		}
		return stringList;
	}
	
	public static WebElement btnClick(String xpath){
		WebElement actionObject = null;
		try {
			actionObject = driver.findElement(By.xpath(xpath));
			actionObject.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return actionObject;
	}
	
	public static void wait(int waitInSeconds){
		try {
			Thread.sleep(waitInSeconds * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
