package com.todomvc.utility;

public class ObjectRepository {


	public static String whatNeedsToBeDone_EB = "//input[@id='new-todo']";
	public static String toDoList = "(//label[@class='ng-binding'])";
	public static String completeBtn = "(//input[@ng-model='todo.completed'])[i]";
	public static String markAll = "//input[@id='toggle-all']";
	public static String completedFilter = "//a[contains(text(),'Completed')]";
	public static String clearCompleted = "//button[@id='clear-completed']";

}
