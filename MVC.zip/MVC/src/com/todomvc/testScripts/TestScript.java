package com.todomvc.testScripts;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import java.awt.RenderingHints.Key;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.todomvc.utility.Env;
import com.todomvc.utility.ObjectRepository;
import com.todomvc.utility.ToDoMvc;

public class TestScript {
	 ObjectRepository or;
	 ToDoMvc mvc;
	 String firstToDo = "Enroll For Java";
	 String secondTodo;
	
	@BeforeTest
	public void setUp(){
		or = new ObjectRepository();
		mvc = new ToDoMvc();
		mvc.openBrowser(Env.mcvUrl);
	}
	 
	@AfterTest
	public void tearDown(){
		mvc.closeBrowser();
	}

	// 1) ADD TO DO ITEM
	@Test(priority = 0)
	public void addToDoItem(){		
		boolean isAdded = mvc.addAToDoList(firstToDo);
		mvc.wait(2); 
		if (isAdded) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	// 2)EDIT THE CONTENT OF AN EXISTING ITEM
	@Test(priority = 5)
	public void editContent(){
		mvc.editToDoItem(firstToDo, "Enrol For New Java");
		firstToDo = "Enrol For New Java";
		Integer itemIndex = mvc.verifyIfToDoItemPresent(firstToDo);
		if (itemIndex != -1) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	// 3) Complete a To Do List
	@Test(priority = 10)
	public void completeToDoValidation(){
		Integer itemIndex = mvc.completeToDoItem(firstToDo);
		mvc.wait(2);
		if (itemIndex != -1) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	// 4) Re-Activate Completed To Do (here we can reuse completeToDoItem method
	@Test(priority = 15)
	public void reActivateCompleted(){
		Integer itemIndex = mvc.completeToDoItem(firstToDo);
		mvc.wait(2);
		if (itemIndex != -1) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	// 5) Add Second ToDo
	@Test(priority = 20)
	public void addSecondToDo(){
		secondTodo = "Pay The Fees";
		mvc.addAToDoList(secondTodo);
		Integer itemIndex = mvc.verifyIfToDoItemPresent(firstToDo);
		if (itemIndex != -1) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	// 6) Complete All Active To-dos by clicking the dropDownArrow
	@Test(priority = 25)
	public void completeAllValidation(){
		WebElement droDownElement = mvc.btnClick(or.markAll);
		mvc.wait(2);
		if (droDownElement != null) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	// 7) Filter the visible To-dos by completed state
	@Test(priority = 30)
	public void filterCompleted(){
		WebElement droDownElement = mvc.btnClick(or.completedFilter);
		mvc.wait(2); //TODO remove these mvc.wait(2);
		if (droDownElement != null) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	// 8) Clear a Single to-do List
	@Test(priority = 35)
	public void clearToDoItem(){
		Integer itemIndex = mvc.clearToDoList(secondTodo);
		mvc.wait(2);
		if (itemIndex != -1) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	
	
	
	// 9) Clear All completed TOdo Items
	@Test(priority = 40)
	public void clearAllCompleted(){
		WebElement droDownElement = mvc.btnClick(or.clearCompleted);
		mvc.wait(2);
		if (droDownElement != null) {
			mvc.writeReport("PASS", "Adding to Do");
		}else{
			mvc.writeReport("FAIL", "Adding to Do");
		}
	}
	

}
