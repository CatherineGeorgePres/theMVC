package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MvcPage {
	
	public static WebElement lnk_click( WebDriver driver){
	WebElement first_link = driver.findElement(By.xpath("//a[@href='examples/angularjs']"));
	
	return first_link;
	}
	
	
	
	public static WebElement add_item(WebDriver driver)
	
	{
		//adding  a first todo 
		WebElement first_todo = driver.findElement(By.xpath("//input[@id='new-todo']"));
		
	
		return first_todo;
	}
	
	
	
	public static WebElement edit_item(WebDriver driver){
		//edit a todo
		WebElement edit_todo = driver.findElement(By.xpath("//label[text()='ADDING STEP 1']/preceding-sibling::input[@type='checkbox']"));
		
		return edit_todo;
	}

public static WebElement make_Complete(WebDriver driver){
	//move to complete

	WebElement click_complete = driver.findElement(By.xpath("(//input[@type='checkbox'])[1]"));
	
	return click_complete;
}
public static WebElement add_SecondTodo(WebDriver driver){

 WebElement add_todo2= driver.findElement(By.xpath("//input[@id='new-todo']"));
 
 return add_todo2;
}



public static WebElement toggle_all(WebDriver driver){
	
WebElement toggle_click = driver.findElement(By.xpath("//input[@id = 'toggle-all']"));
	return toggle_click;
}


public static WebElement close_Completed_todo(WebDriver driver){
	WebElement close_completed = driver.findElement(By.xpath("/html/body/ng-view/section/section/ul/li[1]/div/label"));
	return  close_completed;
	
}

public static WebElement remove_Completed(WebDriver driver){
WebElement remove_todo = driver.findElement(By.xpath("//div/button[@class='destroy']"));
return remove_todo;
}


public static WebElement addthird_todo(WebDriver driver){
	
	WebElement third_todo = driver.findElement(By.xpath("//input[@id='new-todo']"));
	
	return third_todo;
}

public static WebElement filter_Completed(WebDriver driver){
	
	WebElement filtered = driver.findElement(By.xpath("//a[@href='#/completed']"));
	return filtered;
}

public static WebElement clearCompleted(WebDriver driver){

 WebElement clear_AllCompleted = driver.findElement(By.xpath("//button[@id='clear-completed']"));
 return clear_AllCompleted;

}
}