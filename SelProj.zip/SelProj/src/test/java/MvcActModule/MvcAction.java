package MvcActModule;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageObject.MvcPage;

public class MvcAction {
	public static void Execute(WebDriver driver){
		//takes to the first link
		MvcPage.lnk_click(driver).click(); 
		
		//adding first todo
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement add_item = wait.until(ExpectedConditions.elementToBeClickable(MvcPage.add_item(driver)));
		 add_item.sendKeys("ADDING STEP 1",Keys.ENTER);
		 
		
			//Editing a todo item
		 WebElement list_item1 = MvcPage.edit_item(driver);
			
			System.out.println("Before output");
			String value=list_item1.getText();
			if(!value.isEmpty())
			{
				System.out.println("Before output2");
			    Actions act= new  Actions(driver);
			    act.clickAndHold(list_item1);
			    list_item1.clear();
		        act.doubleClick(list_item1).sendKeys("edited VALUE").build().perform();
		
			 
			}
			
			//action3 first step to activate one todo to complete state
			WebElement active_check= MvcPage.make_Complete(driver);	
			active_check.click();
			
			
			
			//action4 
			//reactivate selected back to active state
			active_check.click();
			
			
			//add a second todo
			WebDriverWait wait2 = new WebDriverWait(driver, 30);

			 WebElement add_item2 = wait2.until(ExpectedConditions.elementToBeClickable(MvcPage.add_SecondTodo(driver)));
			 add_item2.sendKeys("Adding STEP 2",Keys.ENTER);
			 
			 
			    //complete all active todo
				WebElement active_check_all= MvcPage.toggle_all(driver);      
				active_check_all.click();
			 
				//close  completed todo's
				WebElement close_comp = MvcPage.close_Completed_todo(driver);
				close_comp.getText();
				
				if(!(close_comp.getText()).isEmpty())
				{
				//remove one completed todo 
					Actions act1= new  Actions(driver);
					act1.clickAndHold(close_comp).build().perform();
				    WebDriverWait wait3 = new WebDriverWait(driver,10);
					WebElement destroy=wait3.until(ExpectedConditions.elementToBeClickable(MvcPage.remove_Completed(driver)));
					destroy.click();
				}
				
				
				
				//adding one  more todo to show filter
					WebDriverWait wait4 = new WebDriverWait(driver,10);
                    WebElement add_item3 = wait4.until(ExpectedConditions.elementToBeClickable(MvcPage.addthird_todo(driver)));
					
					add_item3.sendKeys("Adding STEP 3",Keys.ENTER);
					
					//filter complete
					WebElement  filter_comp= MvcPage.filter_Completed(driver);
					filter_comp.click();
					
					//Clear all Completed
					WebElement clear_Completed = MvcPage.clearCompleted(driver);
					clear_Completed.click();
							
				
			 
		 
	}
}
