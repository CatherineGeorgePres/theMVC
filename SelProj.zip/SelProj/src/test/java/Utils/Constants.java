package Utils;

public class Constants {
	public static final String URL = "http://todomvc.com";
}
