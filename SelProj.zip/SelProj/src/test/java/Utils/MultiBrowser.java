package Utils;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariDriverService;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
 
import org.openqa.selenium.ie.InternetExplorerDriver;
 
import org.testng.annotations.AfterClass;
 
import org.testng.annotations.Test;

import MvcActModule.MvcAction;
public class MultiBrowser {

	private static final TimeUnit SECONDS = null;
 
	public  WebDriver driver;
	
   @Parameters("browser")
   
	@BeforeClass
	
	public void beforeTest(String browser){
		
	   if(browser.equalsIgnoreCase("firefox")) {
	   
	    System.setProperty("webdriver.gecko.driver","D:/Todo/SelProj/Driver/geckodriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		
	   } 
		  else if (browser.equalsIgnoreCase("safari")) { 
		 
	// the path for  IEDriver
		 
			  System.setProperty("webdriver.safari.driver", "D:/Todo/SelProj/Driver/Safari.exe");
		 
			  driver = new SafariDriver();
		 
		  } 
	   
		  else if(browser.equalsIgnoreCase("GC")){
			  System.setProperty("webdriver.chrome.driver", "D:/Todo/SelProj/Driver/chromedriver.exe");
				 
			  driver = new ChromeDriver();  
			  
			  
		  }
	   driver.get(Constants.URL);
		
	}
   
   @Test

	  public void main() throws Exception {

		    MvcAction.Execute(driver);

			
			

			

	        }

	   @AfterClass

	  public void afterTest() {

		    driver.quit();

	        }

	
   
 
}

	